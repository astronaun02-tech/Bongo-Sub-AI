# BongoSub AI — Android prototype

This is an early Android Studio project for a live English-to-Bengali subtitle overlay.

## Important limitations of this prototype
- It does **not** capture MX Player/VLC internal audio. It listens through the phone microphone, so it requires the video to play through the phone speaker. It may not work with headphones or quiet audio.
- Android's SpeechRecognizer provider may use network services and availability/quality varies by device and region.
- Bengali translation uses ML Kit's on-device translation model, downloaded on first use; after download, translation can work offline. Speech recognition itself is not guaranteed offline.
- Partial speech results may be repeated and the overlay is a basic prototype, not polished subtitles.
- Some Android/HyperOS versions may restrict microphone foreground services or overlay behavior. User must grant microphone and display-over-other-apps permissions.

## Build
Open this folder in Android Studio (JDK 17, Android SDK Platform 35). Let Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Test
1. Install the debug APK.
2. Open BongoSub AI and allow microphone + display over other apps (+ notifications if asked).
3. Tap Start subtitles.
4. Play English speech in MX Player or VLC through the phone speaker at a moderate volume.
5. Tap Stop subtitles in BongoSub to stop listening and remove the overlay.

This is a prototype source project, not a compiled or verified APK.

## Build APK with GitHub Actions (no local Android Studio)
Push this project to a GitHub repository on the `main` branch, or open Actions and run **Build debug APK** manually. Download the `BongoSubAI-debug-apk` artifact from the completed workflow. This workflow has not been executed from this environment.
