package com.bongosub.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }
        val title = TextView(this).apply {
            text = "BongoSub AI"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Live English → বাংলা subtitle overlay\n\nPrototype: ফোনের স্পিকারে চলা ভিডিওর শব্দ মাইক্রোফোনে শুনে লেখা ও অনুবাদ করবে। হেডফোনে কাজ নাও করতে পারে।"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply {
            text = "Start subtitles"
            setOnClickListener { prepareAndStart() }
        }
        val stop = Button(this).apply {
            text = "Stop subtitles"
            setOnClickListener { stopService(Intent(this@MainActivity, SubtitleService::class.java)) }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun prepareAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Allow display over other apps, then tap Start again", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestCode)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode + 1)
            return
        }
        startForegroundService(Intent(this, SubtitleService::class.java))
        Toast.makeText(this, "BongoSub started. Play video on speaker.", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) prepareAndStart()
    }
}
