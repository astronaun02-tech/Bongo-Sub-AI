package com.bongosub.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class SubtitleService : Service(), RecognitionListener {
    private var recognizer: SpeechRecognizer? = null
    private var overlay: TextView? = null
    private var translator: Translator? = null
    private var ready = false
    private val channelId = "bongosub_live"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("BongoSub AI is listening")
                .setContentText("Play English video through your phone speaker")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("BongoSub AI is listening")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        }
        startForeground(7, notification)
        createOverlay()
        setupTranslator()
        startRecognition()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "BongoSub live subtitles", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun createOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "BongoSub AI • Listening…"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC111111.toInt())
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
        }
        @Suppress("DEPRECATION")
        val legacyType = WindowManager.LayoutParams.TYPE_PHONE
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else legacyType
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 90 }
        wm.addView(overlay, params)
    }

    private fun setupTranslator() {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        translator = Translation.getClient(options)
        translator?.downloadModelIfNeeded(DownloadConditions.Builder().build())
            ?.addOnSuccessListener { ready = true; updateOverlay("BongoSub ready • Play video on speaker") }
            ?.addOnFailureListener { updateOverlay("Translation model download failed. Check internet.") }
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateOverlay("Speech recognition is unavailable on this device")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { updateOverlay("Could not start speech recognition") }
    }

    private fun translate(text: String) {
        if (text.isBlank()) return
        if (!ready) { updateOverlay("Preparing Bengali translation…\n$text"); return }
        translator?.translate(text)
            ?.addOnSuccessListener { translated -> updateOverlay(translated) }
            ?.addOnFailureListener { updateOverlay("Translation error\n$text") }
    }

    private fun updateOverlay(message: String) {
        overlay?.post { overlay?.text = message }
    }

    override fun onReadyForSpeech(params: android.os.Bundle?) { updateOverlay("Listening…") }
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {
        if (error != SpeechRecognizer.ERROR_CLIENT && error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            overlay?.postDelayed({ startRecognition() }, 700)
        } else updateOverlay("Speech recognition stopped (error $error)")
    }
    override fun onResults(results: android.os.Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!text.isNullOrBlank()) translate(text)
        startRecognition()
    }
    override fun onPartialResults(partialResults: android.os.Bundle?) {
        val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!text.isNullOrBlank()) translate(text)
    }
    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

    override fun onDestroy() {
        recognizer?.destroy(); recognizer = null
        translator?.close(); translator = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(overlay) } catch (_: Exception) {}
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
