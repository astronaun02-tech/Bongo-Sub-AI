plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bongosub.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bongosub.ai"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}

dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
}
